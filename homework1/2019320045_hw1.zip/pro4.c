#include <stdio.h>

int main()
{
	int count = 0;

	printf("\nnumber\tsquare\tcube\n");

	printf("%d\t%d\t%d\n", count, count*count, count*count*count);
	count = count + 1;

	printf("%d\t%d\t%d\n", count, count*count, count*count*count);
	count = count + 1;

	printf("%d\t%d\t%d\n", count, count*count, count*count*count);
	count = count + 1;

	printf("%d\t%d\t%d\n", count, count*count, count*count*count);
	count = count + 1;

	printf("%d\t%d\t%d\n", count, count*count, count*count*count);
	count = count + 1;

	printf("%d\t%d\t%d\n", count, count*count, count*count*count);
	count = count + 1;

	printf("%d\t%d\t%d\n", count, count*count, count*count*count);
	count = count + 1;

	printf("%d\t%d\t%d\n", count, count*count, count*count*count);
	count = count + 1;

	printf("%d\t%d\t%d\n", count, count*count, count*count*count);
	count = count + 1;

	printf("%d\t%d\t%d\n", count, count*count, count*count*count);
	count = count + 1;

	printf("%d\t%d\t%d\n", count, count*count, count*count*count);
}